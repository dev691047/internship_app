const express = require("express");
const router = new express.Router();
const userController = require("../controllers/userControllers");
const internshipController = require("../controllers/internshipController");

// Routes
router.post("/user/register",userController.userregister);
router.post("/user/sendotp",userController.userOtpSend);
router.post("/user/login",userController.userLogin);
router.post("/internship", internshipController.fetchInternships);


module.exports = router;