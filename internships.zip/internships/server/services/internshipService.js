const axios = require('axios');
const data = require('../data/data.json');
const environment = require('../environment/env-local');

const internshipService = {
    fetchInternships: async function (req, callback){
        if(!req || !req.body || !Object.keys(req.body).length>0){
            res.json({
                error_message: "Empty request body.",
                error_code: "400"
            });
            return;
        }
        let payload = req.body;

        if(environment.CURR_ENV.toUpperCase() == "LOCAL"){
            console.log("skipping the api call for local environment.");
            callback(data);
            return;
        }
        const options = {
            method: 'GET',
            url: environment.x_rapid_api_base_url + "/search",
            params: {
                query: payload.query,
                page: payload.page,
                num_pages: payload.numPages
            },
            headers: {
                'X-RapidAPI-Key': environment.x_rapid_api_key,
                'X-RapidAPI-Host': environment.x_rapid_api_host
            }
        };
    
        try {
            console.log("calling api with payload: ", payload);
            const response = await axios.request(options);
            callback(response.data);
        } catch (error) {
            console.error(error);
        }
    }
}


module.exports = internshipService;