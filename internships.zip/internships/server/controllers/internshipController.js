const internshipService = require('../services/internshipService');

exports.fetchInternships = async (req, res) => {
    internshipService.fetchInternships(req, (response)=>{
        res.json(response);
        return;
    });
};
