module.exports = {
    CURR_ENV: 'LOCAL',
    'x_rapid_api_base_url': 'https://jsearch.p.rapidapi.com',
    'x_rapid_api_key': 'ebecbf498fmsh6f4146c0d3d1bccp1f67afjsn5ca88ec259d6',
    'x_rapid_api_host': 'jsearch.p.rapidapi.com'
};