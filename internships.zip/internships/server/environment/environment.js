const LOCAL = require('./env-local');
const PROD = require('./env-prod');

const CURR_ENV = LOCAL;

module.exports = CURR_ENV;