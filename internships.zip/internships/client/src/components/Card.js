import React from 'react'

export default function Card() {
  return (
    <div>Card</div>
  )
}
