import React, { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'


const Dashboard = () => {
  const [data, setData] = useState([]);
  const [error, setError] = useState(null);
  useEffect(() => {
    const fetchData = async () => {
      try {
        debugger;
        // Make API call using fetch
        const response = await fetch('http://localhost:4002/internship', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            "query": "",
            "page": "1",
            "num_pages": "1"
          })  
        });
        if (!response.ok) {
          debugger;
          throw new Error('Network response was not ok');
        }
        const result = await response.json();
        console.log(result);
        setData(result.data);
        setError(null);
      } catch (error) {
        setData(null);
        setError('Error fetching data: ' + error.message);
      }
    };
    fetchData();
  }, []); 

  const userValid = () => {
    let token = localStorage.getItem("userdbtoken");
    if (token) {
      console.log("user valid")
    } else {
      // navigate("*")
    }
  }

  useEffect(() => {
    userValid();
  }, [])
  return (
    <div className="row">
        {data.map((obj, index) => (
          <div className="col-md-12" key={index}>
            <div className="card">
              <div className="card-body">
                <h5 className="card-title">{obj.employer_name}</h5>
                <h3 className=''>{obj.job_title}</h3>
                <div>
                  <a href={obj.job_apply_link} target='_blank' className=''>Apply Now</a>
                </div>
                
              </div>
            </div>
          </div>
        ))}
    </div>
  )
}

export default Dashboard